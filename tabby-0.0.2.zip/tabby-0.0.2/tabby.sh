#!/bin/sh
command=$1
if [ $command = "start" ]; then
java -jar tabby-1.0-SNAPSHOT.jar
fi
